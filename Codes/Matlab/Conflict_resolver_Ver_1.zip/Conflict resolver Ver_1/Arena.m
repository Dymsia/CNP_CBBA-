classdef Arena<handle
    % Using Arena you can create a saple envireonment with some targets 
    
    % Author: Pradeep Kumar Yadav 
    
    % Eg: 
    % Syntex: 
    % Targets = [2200,-1200;3800,-1841;3138,-2311;2910,-1200 ;2400,-2800 ;3600,-2500];
    % sample_arena = Arena(Targets);
    
    
    
    
    
    
    properties(Constant)
        dt = .1;                       % simulation time step (s)
                                        % sampling period (s) for plotting state
        rho = 1;                        % density of Air
        g = 9.8;                        %acceleration due to gravity
        disturbance =  [0;              % wind speed (m/s) in x direction (blowing Eastwards)
            0;              % wind speed (m/s) in y direction (blowing Northwards)
            0;              % wind accel (m/s^2) in x direction
            0];             % wind accel (m/s^2) in y direction
        safety_distance = 250;
    end

     properties
        static_object
        AO_waypoint 
        % the point to which all the UAVs are approching after the takeoff mode
     end
   
    
    methods
        function obj = Arena() % Constructer function
            % static objects positions
            obj.static_object(1).x = 2700;
            obj.static_object(1).y = 0;
            
            obj.static_object(2).x = 4100;
            obj.static_object(2).y = -400;
            
            obj.static_object(3).x = 4750;
            obj.static_object(3).y = 0;
            
            obj.static_object(4).x = 4200;
            obj.static_object(4).y = 750;
            
            obj.AO_waypoint= struct('x',[2000 2000] , 'y' , [-1500 1500], 'z' , 200);
            
        end
  
    end
    
end

