classdef mission_planner<handle
    %Console is the main controller of the program , the commands
    %instructions for the object AirCraft will be generated here
    
    %Author : Pradeep Kumar Yadav
    %Date : 20th may 2013
    
    %   Object from this class will be resposible for the control , the messenger is embeded in
    %   the aircraft itself. you can think of it as the Game planner/designer of the simulation
    
    properties(SetAccess = 'private')
        
        Agents
        % Saves all the UAVs in the mission
        Arena
        % Saves the arena
        running_on
        % running_n = is 1 if the mission planner is planning way points for the 1st UAV and 2 for 2nd UAV ans such for the rest
        takeoff_order
        % Equal to the UAV ID , i.e the first UAV will takeoff first then
        % second UAV and so on
        take_off_orbit
        
        step_number = 1
        % Stores the main itteration number
    end
    
    properties(Constant)
        
        Delta=10000 % Used in the takeoff mode
        
    end
    
    properties(SetAccess = 'private' )
        working_mode        %setting the working mode to take off mode
        
        % working mode of the Aircraft :
        % 1: for the takeoff mode
        % 2: for the fly to AO mode
        % 3: for the search mode
        % 4: for the trackm mode
        
        arc_number = [1 1]
    end
    
    properties (SetAccess = 'public')
        
        takeoff_parameters    % struct('AC_CP_states' , 0 , 'ready_flag',1 , 'AC_current_level', 0,'jump_in_ready', 0)
        
        
        % AC_current_level : aircraft's level of flight during the takeoff mode
        % takeoff flag is 1: already tookoff , else still waiting for the take off
        % AC_CP_states : Aircraft's status in the coordination process
        
        % 0: fly at the current level (not in the holding pattern)
        % 1: fly to the next level
        % 2: fly to the holding pattern
        % 3: fly in the holding pattern
        % 4: timer counts down before switching to the fly_to_AO mode
        WayPointArcs % struct('x', 'y' , 'angle' , 'orientation')
        % stores the data for the arcs to be followed by the UAV
        % (x(1) , y(1)) and (x(2) , y(2)) is the end points and angle is
        % the angle formed by the arc at the center and orientation is to
        % be specified to be followed by the UAV
        
        WayPoint_level % = 0 if the UAV is in between two arcs and going to the next arc
        % = 1 if the UAV is following the arc
        
        NTimer        % the waiting time after which if there is no communication recieved from
        % the other UAV in the level above it, it will
        % then move to the other
        
        ICA                         % intermidiate clib altitude used in the takeoff mode
    end
    
    methods
        
        function obj = mission_planner(UAVs,sample_arena)
            
            obj.Agents = UAVs;
            % initialising the agents data
            obj.Arena = sample_arena;
            % initialising the arena data
            
            obj.working_mode = ones(1,numel(UAVs));
            % initialising all the working mode to takeoff mode
            obj.takeoff_order = transpose(linspace(1,numel(UAVs)));
            obj.NTimer = 20*ones(numel(UAVs));
            
            obj.WayPoint_level = zeros(numel(UAVs));
            for i = 1:1:numel(UAVs)
                % Parameters used in the takeoff mode
                obj.takeoff_parameters(i).AC_CP_states = 0;
                obj.takeoff_parameters(i).ready_flag = 0;
                obj.takeoff_parameters(i).AC_current_level = 0;
                obj.takeoff_parameters(i).jump_in_ready = 0;
                
                
            end
        end
        
        function output = get.take_off_orbit(obj)
            % get function for takeoff_orbit
            if obj.running_on <=3
                output.x=1000;
                output.y=0;
                output.z=300;
                output.rad=300;
                
            else
                output.x=1000;
                output.y=0;
                output.z=200;
                output.rad=300;
                
            end
            
        end
        
        function output = get.takeoff_order(obj)
            % get function for takeoff_order
            output = obj.running_on;
            
        end
        
        function output = get.ICA(obj)
            % get function for ICA
            if obj.running_on <=3
                
                output(1).x=0;
                output(1).y=0;
                output(1).z=100;
                output(1).rad=200;
                output(1).ready=0;         % Level 1 is not the jump-in level for UAVi
                
                output(2).x=0;
                output(2).y=0;
                output(2).z=200;
                output(2).rad=200;
                output(2).ready=1;         % Level 2 is the jump-in level for UAVi
                
                output(3).x=0;
                output(3).y=0;
                output(3).z=200;
                output(3).rad=200;
                output(3).ready=1;
                
            else
                
                
                output(1).x=0;
                output(1).y=0;
                output(1).z=100;
                output(1).rad=200;
                output(1).ready=0;
                
                
                output(2).x=0;
                output(2).y=0;
                output(2).z=200;
                output(2).rad=200;
                output(2).ready=0;
                
                
                output(3).x=0;
                output(3).y=0;
                output(3).z=300;
                output(3).rad=200;
                output(3).ready=1;
            end
        end
        
        function output = get.WayPointArcs(obj)
            if obj.running_on==1
                
                output(1).x =[1800 2300];
                output(1).y =[-1000 -900];
                output(1).angle =90*pi/180;
                output(1).orientation = -1;
                
                output(2).x =[3500 4000];
                output(2).y =[1100 1600];
                output(2).angle =110*pi/180;
                output(2).orientation = 1;
                
                output(3).x =[5000 5500];
                output(3).y =[-1000 -1200];
                output(3).angle =110*pi/180;
                output(3).orientation = -1;
                
                output(4).x =[5500 6000];
                output(4).y =[1000 900];
                output(4).angle =90*pi/180;
                output(4).orientation = 1;
                
            elseif obj.running_on==2
                
                output(1).x =[1800 2200];
                output(1).y =[1500 1600];
                output(1).angle =110*pi/180;
                output(1).orientation = 1;
                
                output(2).x =[3500 4000];
                output(2).y =[-1000 -800];
                output(2).angle =120*pi/180;
                output(2).orientation = -1;
                
                output(3).x =[5200 5500];
                output(3).y =[1100 1000];
                output(3).angle =120*pi/180;
                output(3).orientation = 1;
                
                output(4).x =[5500 5800];
                output(4).y =[-1500 -1600];
                output(4).angle =120*pi/180;
                output(4).orientation = -1;
                
            end
        end
        
        function plan_mission( obj ,k )
            
            obj.running_on = k;
            
            UAVs = obj.Agents;
            
            AC=UAVs(obj.running_on);
            
            arena = obj.Arena;
            
            switch obj.working_mode(k)
                case 1 % UAV is in the takeoff mode
                    AC.cmd=takeoff_mode(obj , AC , arena , UAVs);
                    
                case 2 % UAV is in the Fly_to_AO mode
                    AC.cmd=Fly_to_AO_mode(obj, arena );
                case 3 % follow mission path
                    AC.cmd= follow_path(obj);
            end
            
            
            obj.step_number = obj.Agents(1).step_number;
            
        end
        
    end
    
end


function cmd=takeoff_mode(obj , AC , arena , UAVs )

ID = obj.running_on;
ICA = obj.ICA;
state = AC.state;
level = obj.takeoff_parameters(ID).AC_current_level;
take_off_orbit = obj.take_off_orbit;
n  = obj.step_number;
switch obj.takeoff_parameters(ID).AC_CP_states
    
    case 0  %% when UAV(ii) is at the initial state, do the following operations
        % Operation 1: check whether previously launched UAVs (specified by
        % the takeoff_order) are above the targeting orbitting level of UAV(ii).
        obj.takeoff_parameters(ID).ready_flag = 1; % when Ready_flag == 0, it means some previously launched is not above the targeting orbitting level of UAV(ii)
        % Here we use the last received coordinates of each previously launched UAV for calculation. Therefore, we assume
        % that during the takeoff mode each UAV will not
        % decrease its altitude. Thus, it is valid to use its historical data.
        
        
        for jj=1:numel(UAVs)
            
            if jj < ID && (ICA(obj.takeoff_parameters(jj).AC_current_level+1).z - UAVs(jj).state.h <= 3)
                
                obj.takeoff_parameters(ID).ready_flag = 1;
            end
            
        end
        
        
        if obj.takeoff_parameters(ID).ready_flag == 1  % Once no previously launched UAV is blocking UAV(ii), UAV(ii) starts to fly to the targetting orbitting level, which is
            % is the next intermediate level.
            obj.takeoff_parameters(ID).AC_CP_states = 1; % move to state 1
            
            level  = level  + 1;
            obj.takeoff_parameters(ID).AC_current_level = level;
            cmd.type = 'orbit';
            cmd.orbit = [ICA(level).x;ICA(level).y;ICA(level).z;12;15;ICA(level).rad;1];
        else  % If some previously launched UAV is blocking UAV(ii), then UAV(ii) maintains its current operation altitude.
            if obj.takeoff_parameters(ID).AC_current_level == 0 % if UAV(ii) is on the ground, keep it on the ground.
                cmd.type = 'onGrd';
                cmd.orbit = [];
            else
                
                cmd.type = 'orbit';  % if UAV(ii) is not on the ground, keep its current altitude
                cmd.orbit = [ICA(level).x;ICA(level).y;ICA(level).z;12;15;ICA(level).rad;1];
            end
        end
        
    case 1 % UAV(ii) is at state 1, which means it is in the ascending process towards the targetting orbitting level.
        % We use value a to determine whether UAV(ii) reaches its
        % targetting level, i.e., whether its distance from the centroid of
        % the orbit is sufficiently small.
        a = abs(((state.x-ICA(level).x)^2+(state.y-ICA(level).y)^2+(state.h-ICA(level).z)^2)-(ICA(level).rad)^2);
        
        switch a < obj.Delta
            case 0  % The distance of UAV(ii) from the centroid of the orbit is larger than a prespecified threshold value Delta.
                % This means UAVi has not reached the designated targetting level yet. Then UAV(ii) continues climbing.
                cmd.type = 'orbit';
                cmd.orbit =  [ICA(level).x;ICA(level).y;ICA(level).z;12;15;ICA(level).rad;1];
            case 1 % UAV(ii) has reached the designated targetting level. There are two possibilities: either UAV(ii) is at the same level as its prespecified holding pattern, or is not.
                % In the first case, which is called a jump-in level described by
                % ICA(ii,UAV_current_levels(ii)).ready == 1, UAV(ii)
                % decides to merge into the holding pattern. In the
                % second case, UAV(ii) continues its climbing by
                % returning back to state 0.
                
                switch ICA(level).ready == 1
                    case 0 % the current level is not the jump-in level for UAV(ii)
                        obj.takeoff_parameters(ID).AC_CP_states = 0; % UAVi goes back to state 0 and will continue climbing to the next intermediate level
                        cmd.type = 'orbit';
                        cmd.orbit = [ICA(level).x;ICA(level).y;ICA(level).z;12;15;ICA(level).rad;1];
                    case 1 % the current level is the jump-in level for UAV(ii)
                        % UAVi waits for a gap to appear in the holding
                        % pattern before joining in.
                        
                        % Considering the current setup of the holding pattern we require all UAVs to jump into a holding pattern from the 1th quadron of the current intermediate orbit
                        % We first determine the jump-in x-y coordinates,
                        % denoted as (u,v), which gives the shortest
                        % distance from the current coordinates of UAV(ii)
                        % in the first quadron to the holding pattern.
                        
                        if state.x >=0 && state.y >= 0 % To ensure that UAV(ii) is in the first quadron.
                            u = take_off_orbit.x + (take_off_orbit.rad/(sqrt((state.x - take_off_orbit.x)^2+(state.y - take_off_orbit.y)^2)))*(state.x - take_off_orbit.x);
                            v = take_off_orbit.y + (take_off_orbit.rad/(sqrt((state.x - take_off_orbit.x)^2+(state.y - take_off_orbit.y)^2)))*(state.y - take_off_orbit.y);
                            
                            %Calculate the time instant that UAVi reaches (u,v) from its current location
                            ti = sqrt((state.x - u)^2+(state.y - v)^2)/12 + n*arena.dt;  % each step_no takes simParam.dt time unit during simulation
                            
                            % determine the time instant for each UAV in the holding pattern to reach (u,v)
                            obj.takeoff_parameters(ID).jump_in_ready = 1;
                            for j=1:numel(UAVs)
                                if j==ID
                                    continue;
                                end
                                if obj.take_off_orbit.x==take_off_orbit.x && obj.take_off_orbit.y==take_off_orbit.y && obj.take_off_orbit.z==take_off_orbit.z && obj.take_off_orbit.rad==take_off_orbit.rad % && hbRecdHist(2,j,ii)>=3  UAVj has the same holding pattern as UAVi and already in the holding pattern
                                    
                                    %consider which quadron UAVj is and then determine the time instant that UAVj will reach (u,v)
                                    
                                    x_axis = UAVs(j).state.x;
                                    y_axis = UAVs(j).state.y;
                                    
                                    if x_axis >= obj.take_off_orbit.x
                                        theta = atan((y_axis-obj.take_off_orbit.y)/(x_axis-obj.take_off_orbit.x)) + pi - atan((v-obj.take_off_orbit.y)/(u-obj.take_off_orbit.x));
                                    else
                                        theta = atan((y_axis-obj.take_off_orbit.y)/(x_axis-obj.take_off_orbit.x)) - atan((v-obj.take_off_orbit.y)/(u-obj.take_off_orbit.x));
                                        if theta < 0
                                            theta = theta + 2*pi;
                                        end
                                    end
                                    tj = theta*obj.take_off_orbit.rad/15 + n*arena.dt; % assume that the flying speed in the holding pattern is 15
                                    if abs(tj - ti) < 30  % If the gap is lower than 30 seconds, then UAV(ii) cannot jump in.
                                        obj.takeoff_parameters(ID).jump_in_ready = 0;
                                        break;
                                    end
                                end
                            end
                            if obj.takeoff_parameters(ID).jump_in_ready == 1  % When the gap is bigger than 30 seconds, UAV(ii) is ready to jump in the holding pattern
                                cmd.type = 'orbit';
                                cmd.orbit = [take_off_orbit.x;take_off_orbit.y;take_off_orbit.z;12;15;take_off_orbit.rad;1];
                                
                                
                                
                                obj.takeoff_parameters(ID).AC_CP_states = 2;
                                return;
                            end
                        end
                        cmd.type = 'orbit';
                        cmd.orbit = [ICA(level).x;ICA(level).y;ICA(level).z;12;15;ICA(level).rad;1];
                end
        end
    case 2 % UAV(ii) is at state 2, which means it is flying towards and orbitting its holding pattern.
        a = abs(((state.x-take_off_orbit.x)^2+(state.y-take_off_orbit.y)^2+(state.h-take_off_orbit.z)^2)-(take_off_orbit.rad)^2);
        if a < obj.Delta  % UAV(ii) has reached the holding pattern
            obj.takeoff_parameters(ID).AC_CP_states = 3;
        end
        cmd.type = 'orbit';
        cmd.orbit = [take_off_orbit.x;take_off_orbit.y;take_off_orbit.z;12;15;take_off_orbit.rad;1];
    case 3 % UAV(ii) is at state 3, where it is in the holding pattern and starts to check whether other UAVs are also in their holding patterns.
        
        obj.takeoff_parameters(ID).AC_CP_states = 4;  % Once UAV(ii) starts its countdown, it moves to the last state before switching to the fly_to_AO mode.
        %         end
        obj.NTimer(obj.running_on) = 20;
        cmd.type = 'orbit';
        cmd.orbit = [take_off_orbit.x;take_off_orbit.y;take_off_orbit.z;12;15;take_off_orbit.rad;1];
    case 4 % UAV(ii) is at state 4. When countdown reaches zero, UAV(ii) flies to the AO, i.e., switches to the working_mode 2.
        obj.NTimer(obj.running_on) = obj.NTimer(obj.running_on) - 1;
        if obj.NTimer(obj.running_on) == 0
            obj.working_mode(ID) = 2;
        end
        cmd.type = 'orbit';
        cmd.orbit = [take_off_orbit.x;take_off_orbit.y;take_off_orbit.z;12;15;take_off_orbit.rad;1];
end

end

function cmd=Fly_to_AO_mode(obj,arena)

% UAV simply flies towards the given centroid of the AO defined by
% the coordinates [AO_waypoint.x;AO_waypoint.y;AO_waypoint.z]
if obj.running_on==1
    cmd.type = 'wayPt';
    cmd.wayPt = [arena.AO_waypoint.x(1);arena.AO_waypoint.y(1);arena.AO_waypoint.z;14];
    if obj.Agents(obj.running_on).state.x>1500
        obj.working_mode(obj.running_on)=3;
        fprintf('UAV %d is now following the defined path \n' , obj.running_on)
    end
elseif obj.running_on==2
    cmd.type = 'wayPt';
    cmd.wayPt = [arena.AO_waypoint.x(2);arena.AO_waypoint.y(2);arena.AO_waypoint.z;14];
    if obj.Agents(obj.running_on).state.x>1500
        obj.working_mode(obj.running_on)=3;
        fprintf('UAV %d is now following the defined path \n' , obj.running_on)
    end
end


end

function cmd = follow_path(obj)
% Activates when the state.x >1900 ie the area of operation is defined as
% x>1900
AC = obj.Agents(obj.running_on); % The Aircraft

if obj.arc_number(obj.running_on)<=numel(obj.WayPointArcs)
    NewWayPoint = GetNewWayPoint(obj); % Get the new command based on the current situation
    switch NewWayPoint.type
        case 'wayPoint'
            cmd.type = 'wayPt';
            cmd.wayPt = [NewWayPoint.x;NewWayPoint.y;NewWayPoint.z;14];
            
        case 'orbit'
            cmd.type = 'orbit';
            cmd.orbit = [NewWayPoint.x;NewWayPoint.y;AC.state.h;15;14;NewWayPoint.radius;NewWayPoint.orientation];
            
        case 'primitive'
            cmd.type = 'primitive';
            cmd.primitive = [15;AC.state.h;NewWayPoint.yaw]; % [airspd;alt;yaw]
    end
else
    % When no arc is left to be followed by the UAV it will go to point = (8000, 0)
    cmd.type = 'wayPt';
    cmd.wayPt = [8000;0;200;14];
    
end
end

function NewWayPoint = GetNewWayPoint(obj)

level = obj.WayPoint_level(obj.running_on);
% = 0 if the UAV is in between two arcs and going to the next arc
% = 1 if the UAV is following the arc
arc_number = obj.arc_number(obj.running_on); % = 1 , 2 ,3 , 4...
arc = obj.WayPointArcs(arc_number);
% struct('x', 'y' , 'angle' , 'orientation')
% stores the data for the arcs to be followed by the UAV
% (x(1) , y(1)) and (x(2) , y(2)) is the end points and angle is
% the angle formed by the arc at the center and orientation is to
% be specified to be followed by the UAV
AC = obj.Agents(obj.running_on); % The Aircraft


POA.x = arc.x(1);
POA.y = arc.y(1);
POA.z = AC.state.h;
% The next point of approach i,e first end of the arc
yaw = next_yaw(obj, POA); % find the lext yaw to be attained

if level ==0 % In between the two arc
    
    cmd_type = 'primitive';
    
    if sqrt((AC.state.x-POA.x )^2+ (AC.state.y-POA.y)^2)<10
        obj.WayPoint_level(obj.running_on) = 1;
    end
    
    
else % while on the arc
    cmd_type = 'orbit';
    
    x1 = arc.x(1);
    x2 = arc.x(2);
    y1 = arc.y(1);
    y2 = arc.y(2);
    
    r =norm(x1-x2 , y1-y2)/(2*sin(arc.angle)) ; % radius of the arc
    
    m = (y2-y1)/(x2-x1);
    
    x =r*sqrt((1/(1+1/(m^2)))*(1-(sin(arc.angle/2))^2))+(x1+x2)/2; % x coordinate of the center
    y =(-1/m)*(x-(x1+x2)/2)+(y1+y2)/2;% y coordinate of the center
    radius =r;
    orientation =arc.orientation;
    
    
    if norm(AC.state.x-arc.x(2) , AC.state.y-arc.y(2))<20
        obj.WayPoint_level(obj.running_on) = 0;
        obj.arc_number(obj.running_on) = arc_number+1;
    end
end

switch cmd_type
    
    
    case 'orbit'
        NewWayPoint.type = 'orbit';
        NewWayPoint.x = x;
        NewWayPoint.y = y;
        NewWayPoint.radius = radius;
        NewWayPoint.orientation = orientation;
    case 'primitive'
        NewWayPoint.yaw = yaw;
        NewWayPoint.type = 'primitive';
end
end

function yaw = next_yaw(obj , POA)
max_tcpa = 60;% the UAV will not react if the remaining time to collode with the obstecal is less than 1 min
update_frequency = 20; % when to get the new way point
update_flag = mod(obj.step_number , update_frequency)==0;

mm = obj.running_on; % ID of the UAV for which this function is running on
AC = obj.Agents(mm); % The aircraft
safety_distance = obj.Arena.safety_distance;
current_yaw = find_heading( AC);

my_speed = AC.state.v;
my_position = [AC.state.x , AC.state.y];
my_velocity = [my_speed*sin(current_yaw) ,my_speed* cos(current_yaw)];
my_heading = current_yaw;

%==== preparing the list of obstecals
% obstecals(k-th) = struct('position' ,'velocity' , 'heading')
% position = [x cordinate , y coordinate]
% velocity = [x component , y component]
% heading  = angle measured from north

kk =1;
% moving targets
for i =1:1:numel(obj.Agents)
    if i ~=mm
        obstecals(kk).position = [obj.Agents(i).state.x , obj.Agents(i).state.y];
        temp_speed = obj.Agents(i).state.v;
        temp_yaw = find_heading( obj.Agents(i));
        obstecals(kk).velocity = [temp_speed*sin(temp_yaw) ,temp_speed* cos(temp_yaw)];
        obstecals(kk).heading = temp_yaw;
        kk = kk+1;
    end
end
% static targets
for i = 1:1:numel(obj.Arena.static_object)
    obstecals(kk).position = [obj.Arena.static_object(i).x , obj.Arena.static_object(i).y];
    obstecals(kk).velocity = [0 0]; %#ok<*AGROW>
    obstecals(kk).heading = 0;
    kk = kk+1;
end
nn = kk-1;

%======= plotting the vectors ========

if mm == 1 && update_flag==1
    figure(2);
    cla
    hold on;
    
    for i = 1:1:nn
        if i <=2
            X = [obj.Agents(i).vehical_log.x];
            Y = [obj.Agents(i).vehical_log.y];
            if i==1
                
                plot(X , Y , 'c')
                
                temp_vec = [obj.Agents(i).state.x, obj.Agents(i).state.y;...
                    obj.Agents(i).state.x+ 15*my_velocity(1),obj.Agents(i).state.y+ 15*my_velocity(2)];% the heading vector
                plot(temp_vec(:,1) , temp_vec(:,2),'g')
                plot(my_position(1), my_position(2), 'r*')% my position
                circle(my_position(1), my_position(2), obj.Arena.safety_distance/1.5) % safety circle
                % circle is a function defined below in this file
            else
                plot(X , Y , 'b')
            end
        end
        temp_vec = [obstecals(i).position(1), obstecals(i).position(2);...
            obstecals(i).position(1)+ 15*obstecals(i).velocity(1),obstecals(i).position(2)+ 15*obstecals(i).velocity(2)];% the heading vector
        plot(temp_vec(:,1) , temp_vec(:,2),'g')
        plot(obstecals(i).position(1), obstecals(i).position(2), 'r*')
        circle(obstecals(i).position(1), obstecals(i).position(2), obj.Arena.safety_distance/1.5)% safety circle
        % circle is a function defined below in this file
        view(2),grid on  , axis([1000 6200 -1800 1900]);
        
        plot(POA.x , POA.y ,'Marker','pentagram', 'Color',[0 0 0])
        % my next point of approach
    end
elseif mm == 2 && update_flag==1 && obj.Agents(1).state.x>1900
    figure(2)
    hold on
    plot(POA.x , POA.y , 'Marker','pentagram', 'Color',[0 0 0])
    % others next point of approach
end

%%======================================= computations ==========%%

%constants parameters to define and resolve conflics
% refers to the paper
hmin = 10*pi/180;
hmax = 180*pi/180;

jj = 1;
% Finding the time and cpa seperation
for i = 1:1:nn
    
    vec1 = obstecals(i).position-my_position; % relative postion vector
    vec2 = my_velocity-obstecals(i).velocity; % relative velocity vector
    mod_v_rel = sqrt((vec2(1))^2+(vec2(2))^2);
    
    if mod_v_rel >5 % if the relative velocity is significant
        
        tcpa = (vec1(1)*vec2(1)+vec1(2)*vec2(2))/(mod_v_rel)^2;
        pcpa1 = my_position+my_velocity.*tcpa;
        pcpa2 = obstecals(i).position + obstecals(i).velocity.*tcpa;
        
        distance_CPA = sqrt((pcpa1(1)-pcpa2(1))^2+(pcpa1(2)-pcpa2(2))^2);
        if distance_CPA<2*safety_distance && tcpa<max_tcpa && tcpa>5 && tcpa>0 && AC.state.x>1900
            if mod(obj.step_number , 200)==0
                fprintf('UAV %d will collide to obstecal %d in %d sec : Distance is %d \n' ,mm ,i , floor(tcpa) ,floor(distance_CPA))
            end
            %=================finding the required maneuvering
            % refers the rules of Air
            relative_heading = abs(my_heading-obstecals(i).heading);
            
            if obstecals(i).heading~=0
                if relative_heading<pi
                    % in case of moving obstecal
                    if relative_heading<=hmin
                        % overtake
                        if my_heading < obstecals(i).heading
                            % keep going
                            mode = 0;
                        else
                            % cross from right
                            mode = 1;
                        end
                    elseif relative_heading<=hmax && relative_heading>=hmin
                        % obliqe collision expected
                        if my_heading < obstecals(i).heading
                            % keep going
                            mode = 0;
                            
                        else
                            % cross from right
                            mode = 1;
                        end
                        
                    end
                else
                    if my_heading > obstecals(i).heading
                        % keep going
                        mode = 0;
                    else
                        % cross from right
                        mode = 1;
                    end
                    
                end
            else
                % in case of static obstecal
                % cross from right
                mode = 1;
            end
            
            if mode ==0
                % no need to change heading , keep going
                available_angles(jj).data = 0:pi/180:2*pi;
                % all 360 degrees angles are available
                
            elseif mode==1
                % if need to change heading , finding the available options
                xp = pcpa2(1);
                yp = pcpa2(2);
                
                temp_angle1 = asin(distance_CPA/sqrt((my_position(1)-xp)^2+(my_position(2)-yp)^2));
                
                temp_angle2 = asin(safety_distance/sqrt((my_position(1)-xp)^2+(my_position(2)-yp)^2));
                
                temp_available_start_at = my_heading - temp_angle1 + 2*temp_angle2;
                
                available_angles(jj).data = temp_available_start_at:pi/180:my_heading+pi;
                % available_angles(jj-th).data is an array containg the
                % available angles measured from north in clockwise due to
                % jj-th obstecal to which i may collide
                
                
            end
            jj = jj+1;
        end
        
    end
end
num_of_angle_array = jj-1;
% number of arrays of available_angles

%%========= Plotiing the available angles
if jj~=1 && update_flag==1
    for i = 1:1:num_of_angle_array
        if i ==1
            arc(my_position(1) , my_position(2) , 400 ,available_angles(i).data, 'g')
        elseif i == 2
            arc(my_position(1) , my_position(2) , 500 ,available_angles(i).data, 'b')
        elseif i == 3
            arc(my_position(1) , my_position(2) , 600 ,available_angles(i).data, 'r')
        end
        
    end
    
end

%%====finding new yaw=============

% intersection of all the feseable yaw angles

if num_of_angle_array ==3
    mins = [floor(available_angles(1).data(1).*(180/pi)) floor(available_angles(2).data(1).*(180/pi)) , floor(available_angles(3).data(1).*(180/pi))];
    maxs = [floor(max(available_angles(1).data).*(180/pi)) floor(max(available_angles(2).data).*(180/pi)) , floor(max(available_angles(3).data).*(180/pi))];
    
    final_available_angles =  (pi/180)*min(mins):pi/180:min(maxs)*(pi/180);
    
    
elseif num_of_angle_array ==2
    jj = 1;
    
    array1 = floor(available_angles(1).data.*(180/pi));
    array2 = floor(available_angles(2).data.*(180/pi));
    
    if array1(1)>array2(1)
        temp_array = array1;
        array1 = array2;
        array2 = temp_array;
    end
    
    for i = 1:1:numel(array1)
        temp_angle = array1(i);
        for j = 1:1:numel(array2)
            
            if temp_angle == array2(j);
                
                final_available_angles(jj) = temp_angle*(pi/180);
                jj = jj +1;
            end
        end
    end
    
elseif num_of_angle_array==1
    final_available_angles =  available_angles(1).data;
else
    
    final_available_angles = 0:pi/180:2*pi;
end
% cost estimation of the final available yaw angles

% V_ref vectors heading
temp_vec = [my_position(1)-POA.x , my_position(2)-POA.y];
unit_vec = [0 1];
temp_head = acos(dot(temp_vec , unit_vec)/norm(temp_vec));
if temp_vec(1)<0
    temp_head = 2*pi-temp_head;
end

flag = 0;
for i = 1:1:numel(final_available_angles)
    
    cost = sqrt((cos(temp_head)-cos(final_available_angles(i)))^2+(sin(temp_head)-sin(final_available_angles(i)))^2);
    if flag ==0
        minimum = cost;
        which = i;
        flag =1;
    else
        if minimum<cost
            minimum =cost;
            which = i;
        end
    end
    
end

% Final yaw , having minimum cost

if update_flag==1
    
    yaw = final_available_angles(which)*180/pi;
    
else % when update flag ==0
    try
        yaw = AC.cmd.primitive(3);
    catch
        yaw = temp_head*180/pi;
    end
end

end

function heading = find_heading(AC)

prev_pos = [AC.vehical_log(AC.step_number-2).x , AC.vehical_log(AC.step_number-2).y];
current_pos = [AC.vehical_log(AC.step_number-1).x , AC.vehical_log(AC.step_number-1).y];
heading_vec = current_pos-prev_pos;
unit_vec = [0 1];
heading = acos(dot(heading_vec , unit_vec)/norm(heading_vec));
if heading_vec(1)<0
    heading = 2*pi-heading;
    
end

end

function arc(x,y,r , ang ,color)
%x and y are the coordinates of the center of the circle
%r is the radius of the circle
%0.01 is the angle step, bigger values will draw the circle faster but
%you might notice imperfections (not very smooth)

xp=r*sin(ang);
yp=r*cos(ang);
switch color
    case 'r'
        plot(x+xp,y+yp , 'r');
    case 'b'
        plot(x+xp,y+yp , 'b');
    case 'y'
        plot(x+xp,y+yp , 'y');
    case 'g'
        plot(x+xp,y+yp , 'g');
end
end

function circle(x,y,r)
%x and y are the coordinates of the center of the circle
%r is the radius of the circle
%0.01 is the angle step, bigger values will draw the circle faster but
%you might notice imperfections (not very smooth)

ang=0:0.01:2*pi;
xp=r*cos(ang);
yp=r*sin(ang);
plot(x+xp,y+yp , 'r');
end

