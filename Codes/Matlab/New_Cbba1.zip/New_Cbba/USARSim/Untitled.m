N = 5;
M = 7;

for n=1:N,
    if(n/N <= 0.5),
        A(n) = [(N-n)*2,0,0];
        UAV(n) = initializeRobot('AirRobot', 'AirRobot', A, [0,0,0]);
    else,
        UAV(n) = initializeRobot('AirRobot2', 'AirRobot2', A, [0,0,0]);
    end
    pause(3)
end

pause(10)

for n=1:N,
    UAV(n).stop();
    UAV(n).shutdown();
end

shutdownUSAR();