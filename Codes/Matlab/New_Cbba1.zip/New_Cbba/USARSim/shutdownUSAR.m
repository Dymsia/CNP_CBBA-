clear java
javarmpath('USARSim\USARSimJava')