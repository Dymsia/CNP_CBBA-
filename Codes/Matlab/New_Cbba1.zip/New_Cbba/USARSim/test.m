odometry0 = getOdometryReadings(rob);
encoders0 = getEncoderReadings(rob);
diff = 0;
while diff < 360
    sendDriveCommand(rob, [-10 -10]);
    pause(0.1);
    encoders1 = getEncoderReadings(rob);
    diff = abs(mean(encoders1.Ticks)-mean(encoders0.Ticks));
    disp(diff)
end
sendDriveCommand(rob, [0 0]);
odometry1 = getOdometryReadings(rob);