% Clear environment
close all; clear all;
addpath(genpath(cd));
javaaddpath('USARSim\USARSimJava');
% profile on
Path = struct();

Path(1).x = 1;
Path(1).y = 1;
Path(1).z = 0;
Path(1).t = 1;

Path(2).x = -3;
Path(2).y = 1;
Path(2).t = 1;

Path(3).x = 4;
Path(3).y = 4;
Path(3).t = 1;

Path(4).x = 4;
Path(4).y = 1;
Path(4).t = 1;

Path(5).x = 1;
Path(5).y = 1;
Path(5).t = 1;

Path(6).x = 0;
Path(6).y = 0;
Path(6).t = 1;

SizePath = size(Path);
LenPath = SizePath(2);
   
UAV = initializeRobot('AirRobot', 'AirRobot', [Path(1).x, Path(1).y, 0], [0,0,0]);
pause(Path(1).t);
truth(1)= getGroundTruth(UAV);
 
for i=2:LenPath,
    Path(i).z = 0;
    if i==2,
        Start.x = Path(1).x;
        Start.y = Path(1).y-1;
        Start.z = 0;
        MissionGoTo(UAV, Start, Path(1), Path(2));
        truth(i) = getGroundTruth(UAV);
    else
        MissionGoTo(UAV, Path(i-2), Path(i-1), Path(i));
        truth(i) = getGroundTruth(UAV);
    end
end

for i=1:LenPath-1,
    X1 = [Path(i).x, Path(i+1).x];
    Y1 = [Path(i).y, Path(i+1).y];
    S1 = ['-','o','r'];
    X2 = [truth(i).Position(2), truth(i+1).Position(2)];
    Y2 = [truth(i).Position(1), truth(i+1).Position(1)];
    S2 = ['-','o','g'];
    plot(X1,Y1,S1), grid on
    plot(X2,Y2,S2), grid on
    title('Path Robot on Point and Real Time')
    xlabel('X')
    ylabel('Y')
    hold on
    text(Path(i).x-0.2,Path(i).y-0.2, ['P' num2str(i)]);
    text(truth(i).Position(2)+0.1,truth(i).Position(1)+0.1, ['R' num2str(i)]);
end

pause(5);

UAV.stop();
UAV.shutdown();

shutdownUSAR();
