% Clear environment
close all; clear all;
addpath(genpath(cd));
javaaddpath('USARSim\USARSimJava');
% profile on

FilePath = load('agents\agent1');

SizePath = size(FilePath.Path);
LenPath = SizePath(1);
  
Path = FilePath.Path;
path0 = Path(1,1:4);
UAV = initializeRobot('AirRobot', 'AirRobot', [path0(2), path0(1), path0(3)], [0,0,0]);
pause(path0(4));
truth(1)= getGroundTruth(UAV);
 
for i=2:LenPath,
    if i==2,
        Start = [path0(1), path0(2)-1 ,path0(3)];
        MissionGoTo(UAV, Start, Path(i-1,1:4), Path(i,1:4));
        truth(i) = getGroundTruth(UAV);
    else
        MissionGoTo(UAV, Path(i-2,1:4), Path(i-1,1:4), Path(i,1:4));
        truth(i) = getGroundTruth(UAV);
    end
end

for i=1:LenPath-1,
    X1 = [Path(i,1), Path(i+1,1)];
    Y1 = [Path(i,2), Path(i+1,2)];
    S1 = ['-','o','r'];
    X2 = [truth(i).Position(2), truth(i+1).Position(2)];
    Y2 = [truth(i).Position(1), truth(i+1).Position(1)];
    S2 = ['-','o','g'];
    plot(X1,Y1,S1), grid on
    plot(X2,Y2,S2), grid on
    title('Path Robot on Point and Real Time')
    xlabel('X')
    ylabel('Y')
    hold on
    text(Path(i,1)-0.2,Path(i,2)-0.2, ['P' num2str(i)]);
    text(truth(i).Position(2)+0.1,truth(i).Position(1)+0.1, ['R' num2str(i)]);
end
text(Path(LenPath,1)-0.2,Path(LenPath,2)-0.2, ['P' num2str(LenPath)]);

pause(5);

UAV.stop();
UAV.shutdown();

shutdownUSAR();
