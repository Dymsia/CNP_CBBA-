%*********************************************************  
%    Desarrollado por: Guillermo Montoya                 *
%                                                        *
%    e-mail: logicasoftware@yahoo.com                    *
%                                                        *
%                                                        *
%*********************************************************
%  Programa para la resoluci�n del *  
%  Problema de Transporte de PL    *
%  M�todo de la Esquina Noroeste   *
%***********************************

function [x,costo]=m_transporte(s,d,c);
% function [x, cost] =transporte (s, d, c)
%
% s = �� ����������� (m*1)
% d = �� ������ (n*1)
% c = ���� (m*n)
% x = soluci�n �ptima (m*n)
% cost = ���� ���������� m�nimo

global vs us cuadro nb b2 c2 costo TITULUS TITULVS Calcular;
cost=[];

% ������� b ��� ����� � ������ ��� ���������� b�sicas
% � ���� ��� ���������� �� b�sicas.
%clc
disp(' ������� ������-������ ���� ���� soluci�n b�sica �������.');
disp(' ������� ���������� [x s;d'' 0]')
[x,b]=noroeste(s,d);
[x s;d' 0]
disp(' ')
costo_ini=num2str(sum(sum(c.*x)));
disp([' ���� ���������� = ',num2str(sum(sum(c.*x)))]);
disp(' ')
%%%%
[tamx,tamy]=size(x);
resultado(tamx,tamy);
%%%%
set(nb,'visible','off');
set(vs,'visible','off');
set(us,'visible','off');
set(TITULUS,'visible','off');
set(TITULVS,'visible','off');
vbc=0;%acumulador, ����� ��������
for i = 1:tamx
    for j = 1:tamy
        if (x(i,j)~=0)
            set(cuadro(i,j),'String',num2str(x(i,j)));
            vals1=sprintf('%d',x(i,j));
            vals2=sprintf('%d',c(i,j));
            vbas{i+j}=sprintf('X %d,%d = %s',i,j,vals1);
            mult=sprintf('%d',x(i,j)*c(i,j));
            cosbas{i+j}=sprintf('%s x %s = %s',vals1,vals2,mult);
        end
        set(costo(i,j),'String',num2str(c(i,j)));
    end

end
%%%%
tp=d';
for j = 1:tamy
    set(b2(1,j),'String',num2str(tp(1,j)));
end
%%%%
for i = 1:tamx
    set(c2(i,1),'String',num2str(s(i,1)));
end
%%%%
solbasica(vbas,cosbas,costo_ini);
%pause
waitfor(warndlg('Initial support solution... Press (OK), to continue','Assignment Window'));
iter=0;
while 1
    [u,v]=multiplicadores(x,c,b);
    disp(' Cost Window [c u;v'' 0]');
    [c u;v' 0]
    %%%%%
    set(TITULUS,'visible','on');
    set(TITULVS,'visible','on');
    set(vs,'visible','on');
    set(us,'visible','on');
    %%%%%
    %%%%
    tk=v';
    for j = 1:tamy
        set(vs(1,j),'String',num2str(tk(1,j)));
    end
    %%%%
    for i = 1:tamx
        set(us(i,1),'String',num2str(u(i,1)));
    end
    %%%%

    %%%%%
    %pause
    waitfor(warndlg('Found potentials... Press (OK), to continue','Assignment Window'));
    disp(' ')
    disp(' Reduce cost ')
    r=(c-u*ones(size(v'))-ones(size(u))*v')*(-1);
    %%%
    set(nb,'visible','off');
    %%%%
    for i = 1:tamx
        for j = 1:tamy
            if (r(i,j)~=0)
                set(nb(i,j),'visible','on');
                set(nb(i,j),'String',num2str(r(i,j)));
            end
        end
    end
    %%%%

    %%%
    if any(any(r<0))
        disp(' ')
        [maxv,i,j] = maspos(r);
        if(maxv==0)
            break
        end
    else
        break
    end;
    disp(' ')
    disp(' Assignment window [x s;d'' 0]');
    var_ent=sprintf('Add X %d,%d with cost = %d',i,j,maxv);
    waitfor(warndlg(var_ent,'Variable m�s is positive, ��� ������'));
    [x,b]=ciclo(x,i,j,b);
    [x s;d' 0]
    %%%%
    for i = 1:tamx
        for j = 1:tamy
            if (b(i,j)==1)
                set(cuadro(i,j),'String',num2str(x(i,j)));
            else
                set(cuadro(i,j),'String','');
            end
        end
    end
    %%%%
    disp(' ')
    %pause
    waitfor(warndlg('Construction of applied cycle... Press(OK), to continue','Assignment Window'));
    cost=[cost ; sum(sum(c.*x))];
    fprintf('Assignment cost = %g\n\n',cost(length(cost)));
    etiq=sprintf('Assignment cost = %g for Iteration %d',cost(length(cost)),iter+1);
    waitfor(warndlg(etiq,'Assignment Cost'));
    cost_iter{iter+1}=sprintf('\n%d )- %d',iter+1,cost(length(cost)));
    iter=iter+1;
end
%%%%%
for i = 1:tamx
    for j = 1:tamy
        if (~isempty(get(cuadro(i,j),'String')))
            valsb1=sprintf('%d',x(i,j));
            valsb2=sprintf('%d',c(i,j));
            vbasc{j,i}=sprintf('X %d,%d = %s',i,j,valsb1);
            multb=sprintf('%d',x(i,j)*c(i,j));
            costbas{j,i}=sprintf('%s x %s = %s',valsb1,valsb2,multb);
        end
    end
end

%%%%%
disp(' ')
%pause
waitfor(warndlg('����������� C�lculo... Press (OK), to continue','Assignment Window'));
fprintf('Cost of assignments for all iterations:\n');
cost
if(isempty(cost))
else
    solcosto(cost_iter,cost(length(cost)),vbasc,costbas);
end

set(Calcular,'enable','on');
