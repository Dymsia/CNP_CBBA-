close all
clc
clear

num_of_UAVs = 4; % Num of UAVs

time = 1300;

sample_arena = Arena; % Arena , If you want to change the position of static 
% Obstacals, see the Arena.m file

tic

for i = 1:1:num_of_UAVs
    % Initialising the Aircrafts
    UAVs(i) = AirCraft(i);
 
end

sample_mission_planner = mission_planner(UAVs, sample_arena );
% Initialising the mission planner
N = time/sample_arena.dt;
%% Loop run

for i = 1:1:N
    
    for k = 1:1:numel(UAVs)
        
        sample_mission_planner.plan_mission(k);
        % Plan mission i,e get the new command for the k-th UAV
    end
    
    for k = 1:1:numel(UAVs)
        UAVs(k).move(sample_arena);
        % move the K-th UAV
    end
   
end


toc

%% Figure plots
figure (1);
hold on

for l = 1:1:num_of_UAVs
    X = [UAVs(l).vehical_log.x];
    Y = [UAVs(l).vehical_log.y];
    Z = [UAVs(l).vehical_log.h];
    if l == 1
        plot3(X , Y , Z,'y')
    elseif l == 2
        plot3(X , Y , Z , 'g')
           elseif l == 3
        plot3(X , Y , Z , 'k')
        
    end
    
end

buildings = sample_arena.static_object;

plot([buildings(1).x;buildings(2).x;buildings(3).x;buildings(4).x] , [buildings(1).y;buildings(2).y;buildings(3).y;buildings(4).y],'bs')
title('Routes followed by the UAVs','fontsize',7)
xlabel('East(m)')
ylabel('North(m)')
zlabel('Up(m)')

axis equal , grid on , pause(0.01),hold off;


for i = 1:1:num_of_UAVs
    
    speed(:,i) = [UAVs(i).vehical_log.v];
    heading(:,i) = [UAVs(i).vehical_log.psi];
    bank(:,i) = [UAVs(i).vehical_log.phi];
    height(:,i) = [UAVs(i).vehical_log.h];
    
end

figure(3)
subplot(4,1,1)
plot(speed)
xlabel('time (s)','fontsize',7)
ylabel('air spd (m/s)','fontsize',7)

subplot(4,1,2)
plot(heading)
xlabel('time (s)','fontsize',7)
ylabel('hdg (deg)','fontsize',7)


subplot(4,1,3)
plot(bank)
xlabel('time (s); solid - actual; dotted - cmd','fontsize',7)
ylabel('bank (deg)','fontsize',7)
subplot(4,1,4)
plot(height)
xlabel('time (s)','fontsize',7)
ylabel('ht (m)','fontsize',7)

